// the include-file for sort.c
void sort(char *arr[], int length);
