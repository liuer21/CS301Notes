// prototype for sorting function in sort.c
extern void sortByGiven(char* given[], char* surname[],
			int year[], int recordCount);
